##### TIME SERIES Analysis ########################

############# Life Expectancy#############
library(ggplot2)
library(forecast)

# Assuming your data frame is named 'data' and 'Time' is a time variable
# Convert 'Time' to a time series object
dataset$Time <- as.Date(dataset$Time, format="%Y")

ts_life.expectancy <- ts(dataset$LifeExpectancy, start = min(2008), end = max(2040), frequency = 1)

# Plot the time series data
autoplot(ts_life.expectancy) +
  labs(title = "Life Expectancy Over Time",
       y = "Life Expectancy",
       x = "Time")

# Fit ARIMA model
arima_model <- auto.arima(ts_life.expectancy)
summary(arima_model)

# Forecast future values
forecast_values <- forecast(arima_model, h = 5)  # Change 'h' as needed for the number of forecasted points

# Plot the forecast
autoplot(forecast_values) +
  labs(title = "Life Expectancy Forecast",
       y = "Life Expectancy",
       x = "Time")


############# Health Expenditure #############
##library(ggplot2)
##library(forecast)

# Assuming your data frame is named 'data' and 'Time' is a time variable
# Convert 'Time' to a time series object
##data$Time <- as.Date(data$Time, format="%Y")

ts_HealthExpenditure <- ts(dataset$HealthExpenditure, start = min(2008), end = max(2040), frequency = 1)

# Plot the time series data
autoplot(ts_HealthExpenditure) +
  labs(title = "Health Expenditure Over Time",
       y = "Health Expenditure",
       x = "Time")

# Fit ARIMA model
arima_model1 <- auto.arima(ts_HealthExpenditure)
summary(arima_model1)

# Forecast future values
forecast_values1 <- forecast(arima_model1, h = 5)  # Change 'h' as needed for the number of forecasted points


# Plot the forecast
autoplot(forecast_values1) +
  labs(title = "Health Expenditure Forecast",
       y = "Health Expenditure",
       x = "Time")



############# Undernourishment #############
##library(ggplot2)
##library(forecast)

# Assuming your data frame is named 'data' and 'Time' is a time variable
# Convert 'Time' to a time series object
##data$Time <- as.Date(data$Time, format="%Y")

ts_Undernourishment <- ts(dataset$Undernourishment, start = min(2008), end = max(2040), frequency = 1)

# Plot the time series data
autoplot(ts_Undernourishment) +
  labs(title = "Undernourishment Over Time",
       y = "Undernourishment",
       x = "Time")

# Fit ARIMA model
arima_model2 <- auto.arima(ts_Undernourishment)
summary(arima_model2)

# Forecast future values
forecast_values2 <- forecast(arima_model2, h = 5)  # Change 'h' as needed for the number of forecasted points


# Plot the forecast
autoplot(forecast_values2) +
  labs(title = "Undernourishment Forecast",
       y = "Undernourishment",
       x = "Time")



############# Basic Sanitation #############
##library(ggplot2)
##library(forecast)

# Assuming your data frame is named 'data' and 'Time' is a time variable
# Convert 'Time' to a time series object
##data$Time <- as.Date(data$Time, format="%Y")

ts_BasicSanitation <- ts(dataset$BasicSanitation, start = min(2008), end = max(2040), frequency = 1)

# Plot the time series data
autoplot(ts_BasicSanitation) +
  labs(title = "Basic Sanitation Over Time",
       y = "Basic Sanitation",
       x = "Time")

# Fit ARIMA model
arima_model3 <- auto.arima(ts_BasicSanitation)
summary(arima_model3)

# Forecast future values
forecast_values3 <- forecast(arima_model3, h = 5)  # Change 'h' as needed for the number of forecasted points

# Plot the forecast
autoplot(forecast_values3) +
  labs(title = "Basic Sanitation",
       y = "Basic Sanitation ",
       x = "Time")



############# Basic Drinking Water #############
##library(ggplot2)
##library(forecast)

# Assuming your data frame is named 'data' and 'Time' is a time variable
# Convert 'Time' to a time series object
##data$Time <- as.Date(data$Time, format="%Y")

ts_BasicDrinkingWater <- ts(dataset$BasicDrinkingWater, start = min(2008), end = max(2040), frequency = 1)

# Plot the time series data
autoplot(ts_BasicDrinkingWater) +
  labs(title = "Basic Drinking Water ",
       y = "Basic Drinking Water",
       x = "Time")

# Fit ARIMA model
arima_model4 <- auto.arima(ts_BasicDrinkingWater)
summary(arima_model4)

# Forecast future values
forecast_values4 <- forecast(arima_model4, h = 5)  # Change 'h' as needed for the number of forecasted points


# Plot the forecast
autoplot(forecast_values4) +
  labs(title = "Basic Drinking Water",
       y = "Basic Drinking Water",
       x = "Time")
