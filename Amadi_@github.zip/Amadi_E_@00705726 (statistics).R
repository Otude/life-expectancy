# 1.Load necessary libraries 

 
install.packages("mosaic")
install.packages("datarium")
install.packages("tidyverse")
install.packages("corrplot")
install.packages("rcompanion")
install.packages("qqplotr")
install.packages("ggplot2")
install.packages("RVAideMemoire")
install.packages("car")
install.packages("caret")
install.packages("TTR")
install.packages("forecast")
install.packages("stats")
install.packages("e1071")
install.packages("digest")
install.packages("dplyr")
install.packages("zoo")


library(mosaic)
library(datarium)
library(tidyverse)
library(corrplot)
library(rcompanion)
library(ggplot2)
library(qqplotr)
library(RVAideMemoire)
library(car)
library(caret)
library(stats)
library(TTR)
library(forecast)
library(e1071)
library(digest)
library(dplyr)
library(zoo)


# 2.Load the dataset

dataset <- read.csv("life_expectancy.csv")

# Checking the structure of the dataset

str(dataset)
names(dataset)
head(dataset)
tail(dataset)
summary(dataset)

# Reducing the column name size

dataset <- read.csv("life_expectancy.csv") %>% 
  rename(Country = 'Country.Name',
    LifeExpectancy = 'Life.expectancy.at.birth..total..years...SP.DYN.LE00.IN.',
    HealthExpenditure = 'Current.health.expenditure....of.GDP...SH.XPD.CHEX.GD.ZS.',
    Undernourishment = 'Prevalence.of.undernourishment....of.population...SN.ITK.DEFC.ZS.',
    BasicSanitation = 'People.using.at.least.basic.sanitation.services....of.population...SH.STA.BASS.ZS.',
    BasicDrinkingWater = 'People.using.at.least.basic.drinking.water.services....of.population...SH.H2O.BASW.ZS.',
    LaborForceParticipation = 'Labor.force.participation.rate..total....of.total.population.ages.15....modeled.ILO.estimate...SL.TLF.CACT.ZS.',
    Population1564 = 'Population.ages.15.64....of.total.population...SP.POP.1564.TO.ZS.',
    AgeDependencyRatioOld = 'Age.dependency.ratio..old....of.working.age.population...SP.POP.DPND.OL.')

# 5.Convert all columns except country and time to numeric
dataset$LifeExpectancy <- as.numeric(dataset$LifeExpectancy)
dataset$HealthExpenditure <- as.numeric(dataset$HealthExpenditure)
dataset$Undernourishment <- as.numeric(dataset$Undernourishment)
dataset$BasicSanitation <- as.numeric(dataset$BasicSanitation)
dataset$BasicDrinkingWater <- as.numeric(dataset$BasicDrinkingWater)
dataset$LaborForceParticipation <- as.numeric(dataset$LaborForceParticipation)
dataset$Population1564 <- as.numeric(dataset$Population1564)
dataset$AgeDependencyRatioOld <- as.numeric(dataset$AgeDependencyRatioOld)

# 3.Replace '..' with 0
dataset[dataset == '..'] <- 0

dataset <- dataset[,-4]
dataset <- dataset[,-2]
names(dataset)
head(dataset)

# Summary statistics 
summary(dataset)

# Checking for  Missing Values
any(is.na(dataset))

# dropping of missing values
dataset <- na.omit(dataset)



# Assuming your_data_frame is the name of your data frame and column_name is the name of the column

columns_to_plot <- c("LifeExpectancy", "HealthExpenditure", "Undernourishment", "BasicSanitation","BasicDrinkingWater",
                     "LaborForceParticipation", "Population1564", "AgeDependencyRatioOld")


# Create a box plot for each column
for (col in columns_to_plot) {
  boxplot(dataset[[col]], main=paste("Box Plot of", col), ylab="Values")
}

# Add a title and labels to the plot
title("Life Expectancy")
xlabel <- "Life Expectancy"
ylabel <- "Values"
axis(1, at=1:length(columns_to_plot), labels=columns_to_plot)
axis(2, las=2, at=pretty(dataset[, columns_to_plot]), labels=pretty(dataset[, columns_to_plot]))

# Display the box plots
for (col in columns_to_plot) {
  boxplot(dataset[[col]], main=paste("Box Plot of", col), ylab="Values")
}


# Histogram Plot
columns_to_plot <- c("LifeExpectancy", "HealthExpenditure", "Undernourishment", "BasicSanitation","BasicDrinkingWater",
                     "LaborForceParticipation", "Population1564", "AgeDependencyRatioOld")

# Create a layout for multiple plots
par(mfrow = c(2, 2))

# Loop through each column and create a histogram
for (col in columns_to_plot) {
  hist(dataset[[col]], main = paste("Histogram of", col), xlab = "Values", ylab = "Frequency")
}

# Reset the layout to default
par(mfrow = c(1, 1))




# Columns for which you want to calculate statistics
selected_columns <- c("LifeExpectancy", "HealthExpenditure", "Undernourishment", "BasicSanitation","BasicDrinkingWater",
                       "LaborForceParticipation", "Population1564", "AgeDependencyRatioOld")

# Function to calculate skewness (using e1071 package)
calculate_skewness <- function(x) {
  skewness <- e1071::skewness(x, na.rm = TRUE)
  return(skewness)
}

# Function to calculate kurtosis (using e1071 package)
calculate_kurtosis <- function(x) {
  kurtosis <- e1071::kurtosis(x, na.rm = TRUE)
  return(kurtosis)
}

# Calculate statistics For 12 countries
selected_countries <- c("Austria", "Denmark", "Irland", "Hungary", "France", "United Kingdon",
                        "Ethopia", "Liberia", "Rwanda", "Mozambique", "Sierra Leone", "Senegal")

# Create new columns for mean, median, skewness, and kurtosis for each selected country
statistics_by_country <- data.frame(Country = character(), stringsAsFactors = FALSE)

for (country in selected_countries) {
  subset_data <- dataset[dataset$Country == country, ]
  statistics <- sapply(dataset[, selected_columns], function(x) {
    mean_val <- mean(x, na.rm = TRUE)
    median_val <- median(x, na.rm = TRUE)
    skewness_val <- calculate_skewness(x)
    kurtosis_val <- calculate_kurtosis(x)
    return(c(Mean = mean_val, Median = median_val, Skewness = skewness_val, Kurtosis = kurtosis_val))
  })
  statistics_by_country <- rbind(statistics_by_country, cbind(Country = country, statistics))
}

# Display the updated dataset
print(statistics_by_country)


# 4.2 Corelation Analysis #######################################

# Correlation Analysis

# Columns for which you want to calculate correlations
selected_columns <- c("LifeExpectancy", "HealthExpenditure", "Undernourishment", "BasicSanitation","BasicDrinkingWater",
                      "LaborForceParticipation", "Population1564", "AgeDependencyRatioOld")


# Calculate correlations
correlation_matrix <- cor(dataset[, selected_columns], use = "complete.obs")

# Display the correlation matrix
print(correlation_matrix)
# Plot the correlation matrix using corrplot
corrplot(correlation_matrix, method = "color")





# Linear Regression model with multiple independent variables
my_multiple_linear_model <- lm(LifeExpectancy ~ HealthExpenditure + Undernourishment + BasicSanitation + BasicDrinkingWater + LaborForceParticipation + Population1564 + AgeDependencyRatioOld, data = dataset)

# Summary of the multiple regression model
summary(my_multiple_linear_model)

# Diagnostic plots
residuals_multiple <- residuals(my_multiple_linear_model)

# Diagnostic plots

# Linearity Check
plot(my_multiple_linear_model)

# Normality Check
hist(residuals_multiple)
qqnorm(residuals_multiple)
qqline(residuals_multiple)

# Residuals Independence Check
plot(residuals_multiple ~ predict(my_multiple_linear_model))

# Homoscedasticity Check
plot(predict(my_multiple_linear_model), residuals_multiple)

# Multicollinearity Check
vif(my_multiple_linear_model)






### Hypothesis test 1 ###################################

#### Pearson corr Life Expectancy vs Current.health.expenditure #######################
cor_result <- cor.test(dataset$LifeExpectancy, dataset$HealthExpenditure, method = "pearson")

# Print the correlation coefficient and p-value
cat("Correlation Coefficient:", cor_result$estimate, "\n")
cat("P-value:", cor_result$p.value,"\n")

# Set significance level (e.g., 0.05)
alpha<-0.05

# Compare p-value with significance level
if (cor_result$p.value < alpha) {
  cat("The hypothesis test is statistically significant. We reject the null hypothesis.\n")
} else {
  cat("The hypothesis test is not statistically significant. We fail to reject the null hypothesis.\n")
}




#4.3 hypothesis
### Hypothesis test 1 ###################################

#### Pearson corr Life Expectancy vs HealthExpenditure  #######################
cor_result <- cor.test(dataset$LifeExpectancy, dataset$HealthExpenditure, method = "pearson")

# Print the correlation coefficient and p-value
cat("Correlation Coefficient:", cor_result$estimate, "\n")
cat("P-value:", cor_result$p.value,"\n")

# Set significance level (e.g., 0.05)
alpha<-0.05

# Compare p-value with significance level
if (cor_result$p.value < alpha) {
  cat("The hypothesis test is statistically significant. We reject the null hypothesis.\n")
} else {
  cat("The hypothesis test is not statistically significant. We fail to reject the null hypothesis.\n")
}


#### Pearson corr Life Expectancy vs Undernourishment #######################

cor_result1 <- cor.test(dataset$LifeExpectancy, dataset$Undernourishment, method = "pearson")

cat("Correlation Coefficient:", cor_result1$estimate, "\n")
cat("P-value:", cor_result1$p.value,"\n")
alpha<-0.05


# Compare p-value with alpha significance level
if (cor_result1$p.value < alpha) {
  cat("The hypothesis test is statistically significant. We reject the null hypothesis.\n")
} else {
  cat("The hypothesis test is not statistically significant. We fail to reject the null hypothesis.\n")
}



#### Pearson corr Life Expectancy vs BasicSanitation #######################
cor_result2 <- cor.test(dataset$LifeExpectancy, dataset$BasicSanitation, method = "pearson")
cat("Correlation Coefficient:", cor_result2$estimate, "\n")
cat("P-value:", cor_result1$p.value,"\n")


#### Pearson corr Life Expectancy vs BasicDrinkingWater #######################

cor_result3 <- cor.test(dataset$LifeExpectancy, dataset$LaborForceParticipation, method = "pearson")
cat("Correlation Coefficient:", cor_result3$estimate, "\n")
cat("P-value:", cor_result3$p.value,"\n")
alpha<-0.05
# Compare p-value with alpha significance level
if (cor_result3$p.value < alpha) {
  cat("The hypothesis test is statistically significant. We reject the null hypothesis.\n")
} else {
  cat("The hypothesis test is not statistically significant. We fail to reject the null hypothesis.\n")
}













